# 58-field Intent Template POC (from scratch)

This creates a new Excel workbook with **all 58 headers** you provided, no base file required.
It also includes a task to append rows by header name.

## Files
- `cypress/poc/tasks/xlsx_dynamic_58.js` — tasks:
  - `poc:makeTemplate58` — builds the workbook
  - `poc:appendRows58` — appends rows
- `cypress/poc/e2e/intent_58.feature` & `.steps.js` — Cucumber demo

## Wire it into your existing `cypress.config.js`
```js
const cucumber = require('cypress-cucumber-preprocessor').default;
const { registerPocTasks } = require('./cypress/poc/tasks/xlsx_dynamic_58');

module.exports = {
  e2e: {
    setupNodeEvents(on, config) {
      on('file:preprocessor', cucumber());
      registerPocTasks(on, config);
      return config;
    },
    specPattern: ['cypress/e2e/**/*.feature', 'cypress/poc/e2e/**/*.feature']
  }
};
```

## Notes
- The header `Product Type\n(NDC, GPI)` contains a line-break — keep it exactly when appending rows.
- Date columns (`Effective Date`, `Thru Date`, `CT Effective Date`, `CT Thru Date`) are formatted as `mm/dd/yyyy`.
- Adjust widths/validations later by editing `DEFAULT_HEADERS` in `xlsx_dynamic_58.js`.
