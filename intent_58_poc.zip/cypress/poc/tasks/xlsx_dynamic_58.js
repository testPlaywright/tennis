// cypress/poc/tasks/xlsx_dynamic_58.js
const XlsxPopulate = require('xlsx-populate');
const path = require('path');
const fs = require('fs');

function style(range, s) { Object.entries(s || {}).forEach(([k,v]) => range.style(k, v)); }
const norm = s => String(s ?? '').trim().toLowerCase();

const DEFAULT_HEADERS = [
  {
    "name": "PDLM Template Row #"
  },
  {
    "name": "Edit Type"
  },
  {
    "name": "BOM Analyst Attention Flag"
  },
  {
    "name": "List IDs"
  },
  {
    "name": "LOB Codes to Apply"
  },
  {
    "name": "Exclusion LOB Codes to Apply"
  },
  {
    "name": "PEX LOB Codes to Apply"
  },
  {
    "name": "Effective Date"
  },
  {
    "name": "Thru Date"
  },
  {
    "name": "Apply Monthly Rolling Dates"
  },
  {
    "name": "Product Type\n(NDC, GPI)"
  },
  {
    "name": "Product ID"
  },
  {
    "name": "MSC"
  },
  {
    "name": "Coverage Decision"
  },
  {
    "name": "Drug Status"
  },
  {
    "name": "OTC"
  },
  {
    "name": "Pckg"
  },
  {
    "name": "ROA"
  },
  {
    "name": "GPI List Edit"
  },
  {
    "name": "Use Benefit Reset"
  },
  {
    "name": "Drug Status Table"
  },
  {
    "name": "Message Code"
  },
  {
    "name": "Message Text"
  },
  {
    "name": "Message Type"
  },
  {
    "name": "CT Logic"
  },
  {
    "name": "CT Effective Date"
  },
  {
    "name": "CT Thru Date"
  },
  {
    "name": "CT Schedule ID"
  },
  {
    "name": "Bypass CT"
  },
  {
    "name": "Sequence"
  },
  {
    "name": "Age Min"
  },
  {
    "name": "Age Min Unit"
  },
  {
    "name": "Age Max"
  },
  {
    "name": "Age Max Unit"
  },
  {
    "name": "Gender"
  },
  {
    "name": "Bypass Drug Status"
  },
  {
    "name": "Bypass MSC"
  },
  {
    "name": "Mandate States"
  },
  {
    "name": "MandateOption"
  },
  {
    "name": "Mandate Instructions"
  },
  {
    "name": "TOC Batch Lists"
  },
  {
    "name": "Clinical Rule"
  },
  {
    "name": "31 Days and Under"
  },
  {
    "name": "31 Days and Under PQE"
  },
  {
    "name": "31 Days and Under PQE Max"
  },
  {
    "name": "35 Days and Over"
  },
  {
    "name": "35 Days and Over PQE"
  },
  {
    "name": "35 Days and Over PQE Max"
  },
  {
    "name": "P&G 120 Days Supply Limit"
  },
  {
    "name": "P&G 120 Days PQE"
  },
  {
    "name": "P&G 120 Days PQE Max"
  },
  {
    "name": "Specialty"
  },
  {
    "name": "Client Options"
  },
  {
    "name": "Dx2Rx List"
  },
  {
    "name": "Dx2Rx List Qualifier"
  },
  {
    "name": "Dx2Rx List Status"
  },
  {
    "name": "Dx2Rx Message Schedule"
  },
  {
    "name": "Dx2Rx Message Schedule Type"
  }
];

const DATE_NAMES = [
  'Effective Date',
  'Thru Date',
  'CT Effective Date',
  'CT Thru Date'
].map(s => s.toLowerCase());

async function makeTemplate58(args = {}) {
  const {
    outFile = 'CLINICAL_INTENT.xlsx',
    sheetName = 'CAT Automated',
    headers = DEFAULT_HEADERS,
    top = {
      numberingRow: true,
      row5Labels: ["PDLM Template Row #", "Edit Type", "BOM Analyst Attention Flag", "List IDs", "LOB Codes to Apply", "Exclusion LOB Codes to Apply", "PEX LOB Codes to Apply", "Effective Date", "Thru Date", "Apply Monthly Rolling Dates", "Product Type\n(NDC, GPI)", "Product ID", "MSC", "Coverage Decision", "Drug Status", "OTC", "Pckg", "ROA", "GPI List Edit", "Use Benefit Reset", "Drug Status Table", "Message Code", "Message Text", "Message Type", "CT Logic", "CT Effective Date", "CT Thru Date", "CT Schedule ID", "Bypass CT", "Sequence", "Age Min", "Age Min Unit", "Age Max", "Age Max Unit", "Gender", "Bypass Drug Status", "Bypass MSC", "Mandate States", "MandateOption", "Mandate Instructions", "TOC Batch Lists", "Clinical Rule", "31 Days and Under", "31 Days and Under PQE", "31 Days and Under PQE Max", "35 Days and Over", "35 Days and Over PQE", "35 Days and Over PQE Max", "P&G 120 Days Supply Limit", "P&G 120 Days PQE", "P&G 120 Days PQE Max", "Specialty", "Client Options", "Dx2Rx List", "Dx2Rx List Qualifier", "Dx2Rx List Status", "Dx2Rx Message Schedule", "Dx2Rx Message Schedule Type"],
      row6Defaults: Array(58).fill('')
    },
    freeze = { row: 10, col: 2 },
    rows = []
  } = args;

  if (!Array.isArray(headers) || headers.length === 0) {
    throw new Error('headers[] is required');
  }

  const wb = await XlsxPopulate.fromBlankAsync();
  const ws = wb.addSheet(sheetName);
  const defaultSheet = wb.sheet('Sheet1');
  if (defaultSheet) wb.deleteSheet(defaultSheet.name());

  const baseFont = { fontFamily: 'Aptos Narrow', fontSize: 11 };

  // Column widths (slightly wider by default for long labels)
  headers.forEach((h, i) => ws.column(i + 1).width(h.width || 18));

  // Rows: numbering (4), labels (5), defaults (6), spacer (7-8), black header (9)
  const numberingRowIdx = 4;
  const labelsRowIdx = 5;
  const defaultsRowIdx = 6;
  const blackHeaderRowIdx = 9;
  const firstDataRow = blackHeaderRowIdx + 1;

  // numbering
  if (top.numberingRow) {
    headers.forEach((_, i) => ws.cell(numberingRowIdx, i + 1).value(i + 1));
    style(ws.range(numberingRowIdx, 1, numberingRowIdx, headers.length), {
      ...baseFont, horizontalAlignment: 'center', fill: 'E2F0D9', border: true
    });
  }

  // row5 labels
  if (Array.isArray(top.row5Labels) && top.row5Labels.length) {
    top.row5Labels.forEach((t, i) => ws.cell(labelsRowIdx, i + 1).value(t));
    style(ws.range(labelsRowIdx, 1, labelsRowIdx, headers.length), {
      ...baseFont, bold: true, fill: 'C6E0B4', border: true, horizontalAlignment: 'center', wrapText: true
    });
  }

  // row6 defaults
  if (Array.isArray(top.row6Defaults) && top.row6Defaults.length) {
    top.row6Defaults.forEach((v, i) => ws.cell(defaultsRowIdx, i + 1).value(v));
    style(ws.range(defaultsRowIdx, 1, defaultsRowIdx, headers.length), {
      ...baseFont, fill: 'F2F9EE', border: true
    });
  }

  // spacer
  style(ws.range(7,1,8,headers.length), { ...baseFont });

  // black header
  headers.forEach((h, i) => ws.cell(blackHeaderRowIdx, i + 1).value(h.name));
  style(ws.range(blackHeaderRowIdx, 1, blackHeaderRowIdx, headers.length), {
    ...baseFont, bold: true, fill: '000000', fontColor: 'FFFFFF', border: true, wrapText: true
  });

  // formats (dates)
  headers.forEach((h, i) => {
    if (DATE_NAMES.includes(String(h.name).toLowerCase())) {
      ws.range(firstDataRow, i + 1, firstDataRow + 2000, i + 1).style('numberFormat', 'mm/dd/yyyy');
    }
  });

  // freeze
  ws.freezePanes(freeze.row || firstDataRow, freeze.col || 2);

  // data grid
  style(ws.range(firstDataRow, 1, firstDataRow + 2000, headers.length), { ...baseFont, border: true });

  // optional initial rows
  rows.forEach((rowObj, idx) => {
    const r = firstDataRow + idx;
    headers.forEach((h, i) => {
      if (Object.prototype.hasOwnProperty.call(rowObj, h.name)) {
        ws.cell(r, i + 1).value(rowObj[h.name]);
      }
    });
  });

  const outDir = path.join(process.cwd(), 'cypress', 'downloads');
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });
  const outPath = path.join(outDir, outFile);
  await wb.toFileAsync(outPath);
  return { fileName: outFile, fullPath: outPath };
}

async function appendRows58({ filePath, rows = [] }) {
  if (!filePath) throw new Error('appendRows58: filePath is required');
  const wb = await XlsxPopulate.fromFileAsync(filePath);
  const ws = wb.sheets()[0];

  const headerRowIdx = 9;
  const firstDataRow = headerRowIdx + 1;

  // header map
  const map = {};
  for (let c = 1; c <= 500; c++) {
    const v = ws.cell(headerRowIdx, c).value();
    if (v) map[norm(v)] = c;
  }

  // first empty row (check 3 representative columns)
  let r = firstDataRow;
  const checkCols = ['PDLM Template Row #','Edit Type','Product ID'].map(n => map[norm(n)]).filter(Boolean);
  const isEmpty = row => checkCols.every(c => { const v = ws.cell(row, c).value(); return v == null || String(v).trim() === ''; });
  while (!isEmpty(r)) r++;

  // append
  rows.forEach((obj, idx) => {
    const rr = r + idx;
    Object.entries(obj || {}).forEach(([k, v]) => {
      const col = map[norm(k)];
      if (col) ws.cell(rr, col).value(v);
    });
  });

  await wb.toFileAsync(filePath);
  return filePath;
}

function registerPocTasks(on) {
  on('task', {
    'poc:makeTemplate58': makeTemplate58,
    'poc:appendRows58': appendRows58
  });
}

module.exports = { registerPocTasks };
