import { Given, When, Then } from 'cypress-cucumber-preprocessor/steps';

let xlsxPath;

Given('I create the 58-field intent template', () => {
  cy.task('poc:makeTemplate58', {
    outFile: 'CLINICAL_INTENT.xlsx'
  }).then(({ fullPath }) => { xlsxPath = fullPath; });
});

When('I append a sample row to it', () => {
  const row = {
    'PDLM Template Row #': 't',
    'Edit Type': 'INVALID',
    'List IDs': 'LIST3',
    'LOB Codes to Apply': 'MPL1',
    'Product Type\n(NDC, GPI)': 'NDC',
    'Product ID': '7000000002'
  };
  cy.task('poc:appendRows58', { filePath: xlsxPath, rows: [row] });
});

Then('the file should exist', () => {
  cy.readFile(xlsxPath, null).should('exist');
});
