# Bot-driven Excel Template POC (Cypress + Cucumber)

This POC lets you type a natural-language instruction, parse it into a row,
generate a fresh XLSX template **from scratch**, append that row, and use it in your CAT flow.

## Files
- `cypress/poc/tasks/xlsx_dynamic.js` — tasks to build/append a dynamic template
- `cypress/poc/tasks/bot_parse.js` — task to parse NL instructions -> row object
- `cypress/poc/e2e/bot_intent.feature` — cucumber scenario
- `cypress/poc/e2e/bot_intent.steps.js` — matching steps

## Wiring (in your existing cypress.config.js)
```js
const cucumber = require('cypress-cucumber-preprocessor').default;
const { registerPocTasks } = require('./cypress/poc/tasks/xlsx_dynamic');
const { registerBotTasks } = require('./cypress/poc/tasks/bot_parse');

module.exports = {
  e2e: {
    setupNodeEvents(on, config) {
      on('file:preprocessor', cucumber());
      registerPocTasks(on, config);
      registerBotTasks(on, config);
      return config;
    },
    specPattern: ['cypress/e2e/**/*.feature', 'cypress/poc/e2e/**/*.feature']
  }
};
```

## Example prompt
`"pdlmRow t edit INVALID list LIST3 lob MPL1 type NDC product 7000000002"`
