import { Given, When, Then } from 'cypress-cucumber-preprocessor/steps';

let builtPath;
let parsedRow;

Given('I ask the bot to prepare an intent: {string}', (instruction) => {
  cy.task('bot:parse', { text: instruction }).then(({ row }) => {
    parsedRow = row;
  });
});

When('I generate the Excel from scratch with that row', () => {
  const headers = [
    { name: 'PDLMRow', width: 12 },
    { name: 'EditType', width: 12, validation: ['ADD','MODIFY','INVALID','DELETE'] },
    { name: 'BOMAnalystFlag', width: 16 },
    { name: 'ListIDs', width: 16 },
    { name: 'LOBCodes', width: 16 },
    { name: 'EXCLOBCodes', width: 16 },
    { name: 'PEXLOBCodes', width: 16 },
    { name: 'EffectiveDate', width: 14, format: 'mm/dd/yyyy' },
    { name: 'ThruDate', width: 14, format: 'mm/dd/yyyy' },
    { name: 'ApplyMonthly?', width: 14, validation: ['Y','N'] },
    { name: 'ProductType', width: 14, validation: ['NDC','GPI'] },
    { name: 'ProductID', width: 16 }
  ];
  const top = {
    numberingRow: true,
    row5Labels: headers.map(h => h.name),
    row6Defaults: Array(headers.length).fill('')
  };

  cy.task('poc:makeDynamicTemplate', {
    outFile: 'CLINICAL_INTENT.xlsx',
    sheetName: 'CAT Automated',
    headers,
    top,
    freeze: { row: 9, col: 2 },
    rows: [parsedRow]
  }).then(({ fullPath }) => { builtPath = fullPath; });
});

Then('the XLSX should be created', () => {
  cy.readFile(builtPath, null).should('exist');
  // To use:
  // cy.get('input[type=file]').selectFile(builtPath, { force: true });
});
