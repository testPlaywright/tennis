// cypress/poc/tasks/bot_parse.js
const SYNONYMS = {
  pdlmrow: ['pdlmrow','pdlm','row','template row','pdlm row','tmplrow'],
  edittype: ['edittype','edit','action'],
  listids: ['listids','list','list id','listid'],
  lobcodes: ['lobcodes','lob','mpl','lob code'],
  exclobcodes: ['exclobcodes','exlob','exclude lob','exc lob','ex clob'],
  pexlobcodes: ['pexlobcodes','pex lob','pex'],
  effectivedate: ['effectivedate','from','start','effective'],
  thrudate: ['thrudate','to','end','thru'],
  applymonthly: ['applymonthly','monthly','apply monthly'],
  producttype: ['producttype','type','ptype'],
  productid: ['productid','pid','product','ndc','gpi']
};

const CANON = {
  pdlmrow: 'PDLMRow',
  edittype: 'EditType',
  listids: 'ListIDs',
  lobcodes: 'LOBCodes',
  exclobcodes: 'EXCLOBCodes',
  pexlobcodes: 'PEXLOBCodes',
  effectivedate: 'EffectiveDate',
  thrudate: 'ThruDate',
  applymonthly: 'ApplyMonthly?',
  producttype: 'ProductType',
  productid: 'ProductID'
};

const norm = s => String(s ?? '').trim().toLowerCase();

const LOOKUP = (() => {
  const m = new Map();
  for (const [canon, list] of Object.entries(SYNONYMS)) {
    list.forEach(alias => m.set(norm(alias), canon));
  }
  return m;
})();

function parseInstruction(text) {
  const out = {};
  const tokens = String(text || '').split(/\s+/);

  for (let i = 0; i < tokens.length; i++) {
    const raw = tokens[i];
    if (!raw) continue;

    const mColon = raw.match(/^([^:]+):(.*)$/);
    if (mColon) {
      const k = norm(mColon[1]);
      const v = mColon[2];
      const canonKey = LOOKUP.get(k) || k;
      const header = CANON[canonKey];
      if (header) out[header] = (out[header] ? out[header] + ' ' : '') + v;
      continue;
    }

    const k = norm(raw);
    const canonKey = LOOKUP.get(k);
    if (canonKey) {
      const header = CANON[canonKey];
      let v = '';
      let j = i + 1;
      while (j < tokens.length) {
        const nxt = tokens[j];
        const looksKeyColon = /:/.test(nxt);
        const maybeKey = LOOKUP.get(norm(nxt));
        if (maybeKey || looksKeyColon) break;
        v += (v ? ' ' : '') + nxt;
        j++;
      }
      if (header && v) out[header] = v;
      i = j - 1;
    }
  }

  if (out.EditType) out.EditType = out.EditType.toUpperCase();
  if (out.ProductType) out.ProductType = out.ProductType.toUpperCase();
  if (out.ApplyMonthly) out['ApplyMonthly?'] = out.ApplyMonthly;
  delete out.ApplyMonthly;

  return { row: out };
}

function registerBotTasks(on) {
  on('task', {
    'bot:parse': ({ text }) => parseInstruction(text)
  });
}

module.exports = { registerBotTasks };
