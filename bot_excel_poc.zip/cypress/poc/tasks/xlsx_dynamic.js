// cypress/poc/tasks/xlsx_dynamic.js
const XlsxPopulate = require('xlsx-populate');
const path = require('path');
const fs = require('fs');

function style(range, s) { Object.entries(s || {}).forEach(([k,v]) => range.style(k, v)); }
const norm = s => String(s ?? '').trim().toLowerCase();

async function makeDynamicTemplate(args = {}) {
  const {
    outFile = 'CLINICAL_INTENT.xlsx',
    sheetName = 'CAT Automated',
    headers = [],
    top = {},
    freeze = { row: 9, col: 2 },
    rows = []
  } = args;

  if (!Array.isArray(headers) || headers.length === 0) {
    throw new Error('headers[] is required (list of column objects with at least a "name" property).');
  }

  const wb = await XlsxPopulate.fromBlankAsync();
  const ws = wb.addSheet(sheetName);
  const defaultSheet = wb.sheet('Sheet1');
  if (defaultSheet) wb.deleteSheet(defaultSheet.name());

  const baseFont = { fontFamily: 'Aptos Narrow', fontSize: 11 };

  headers.forEach((h, i) => ws.column(i + 1).width(h.width || 14));

  const numberingRowIdx = 4;
  const labelsRowIdx = 5;
  const defaultsRowIdx = 6;
  const blackHeaderRowIdx = 8;
  const firstDataRow = blackHeaderRowIdx + 1;

  if (top.numberingRow) {
    headers.forEach((_, i) => ws.cell(numberingRowIdx, i + 1).value(i + 1));
    style(ws.range(numberingRowIdx, 1, numberingRowIdx, headers.length), {
      ...baseFont, horizontalAlignment: 'center', fill: 'E2F0D9', border: true
    });
  }

  if (Array.isArray(top.row5Labels) && top.row5Labels.length) {
    top.row5Labels.forEach((t, i) => ws.cell(labelsRowIdx, i + 1).value(t));
    style(ws.range(labelsRowIdx, 1, labelsRowIdx, headers.length), {
      ...baseFont, bold: true, fill: 'C6E0B4', border: true, horizontalAlignment: 'center'
    });
  }

  if (Array.isArray(top.row6Defaults) && top.row6Defaults.length) {
    top.row6Defaults.forEach((v, i) => ws.cell(defaultsRowIdx, i + 1).value(v));
    style(ws.range(defaultsRowIdx, 1, defaultsRowIdx, headers.length), {
      ...baseFont, fill: 'F2F9EE', border: true
    });
  }

  headers.forEach((h, i) => ws.cell(blackHeaderRowIdx, i + 1).value(h.name));
  style(ws.range(blackHeaderRowIdx, 1, blackHeaderRowIdx, headers.length), {
    ...baseFont, bold: true, fill: '000000', fontColor: 'FFFFFF', border: true
  });

  ws.freezePanes((freeze.row || firstDataRow), (freeze.col || 2));

  style(ws.range(firstDataRow, 1, firstDataRow + 2000, headers.length), {
    ...baseFont, border: true
  });

  headers.forEach((h, i) => {
    if (h.format) {
      ws.range(firstDataRow, i + 1, firstDataRow + 2000, i + 1).style('numberFormat', h.format);
    }
    if (Array.isArray(h.validation) && h.validation.length) {
      ws.range(firstDataRow, i + 1, firstDataRow + 2000, i + 1).dataValidation({
        type: 'list', allowBlank: true, formula1: `"${h.validation.join(',')}"`
      });
    }
  });

  rows.forEach((rowObj, idx) => {
    const r = firstDataRow + idx;
    headers.forEach((h, i) => {
      if (rowObj[h.name] !== undefined) ws.cell(r, i + 1).value(rowObj[h.name]);
    });
  });

  const outDir = path.join(process.cwd(), 'cypress', 'downloads');
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });
  const outPath = path.join(outDir, outFile);
  await wb.toFileAsync(outPath);
  return { fileName: outFile, fullPath: outPath };
}

async function appendRows({ filePath, rows = [] }) {
  if (!filePath) throw new Error('appendRows: filePath is required');
  const wb = await XlsxPopulate.fromFileAsync(filePath);
  const ws = wb.sheets()[0];

  let headerRowIdx = 8;
  outer: for (let r = 1; r <= 40; r++) {
    let cnt = 0;
    for (let c = 1; c <= 200; c++) {
      const v = ws.cell(r, c).value();
      if (v != null && String(v).trim() !== '') cnt++;
    }
    if (cnt >= 3) { headerRowIdx = r; break outer; }
  }
  const firstDataRow = headerRowIdx + 1;

  const map = {};
  for (let c = 1; c <= 200; c++) {
    const v = ws.cell(headerRowIdx, c).value();
    if (v) map[norm(v)] = c;
  }

  let r = firstDataRow;
  const keyCols = [map['pdlmrow'], map['edittype'], map['productid']].filter(Boolean);
  const isEmpty = row => keyCols.every(c => {
    const v = ws.cell(row, c).value();
    return v == null || String(v).trim() === '';
  });
  while (!isEmpty(r)) r++;

  rows.forEach((obj, idx) => {
    const rr = r + idx;
    Object.entries(obj || {}).forEach(([k, v]) => {
      const col = map[norm(k)];
      if (col) ws.cell(rr, col).value(v);
    });
  });

  await wb.toFileAsync(filePath);
  return filePath;
}

function registerPocTasks(on) {
  on('task', {
    'poc:makeDynamicTemplate': makeDynamicTemplate,
    'poc:appendRows': appendRows
  });
}

module.exports = { registerPocTasks };
